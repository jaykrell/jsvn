#include "j50.h"
#include <errno.h>

long
jk_errno()
{
	long err = errno;
	if (err == 0)
		err -1;
	else if (err > 0)
		err = -err;
	return err;
}
