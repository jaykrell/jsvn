#include "pdb.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <memory.h>
#pragma hdrstop

typedef struct MY_FILE {
    BYTE* Contents;
    size_t Size;
    const char* FileName;
} MY_FILE;

long
ReadEntireFileInMemory(
    const char* FileName,
    MY_FILE* OutFile
    )
{
    long Status = -1;
    FILE* StdioFile = 0;
    size_t BufferSize = 0;
    size_t BytesReadOnce = 0;
    size_t BytesReadTotal = 0;
    size_t BytesToRead = (1U << 8); /* start small */
    MY_FILE File = { 0 };
    void* NextBuffer;

    *OutFile = File;

    StdioFile = fopen(FileName, "rb");
    if (StdioFile == NULL)
        goto Exit;

    while (1)
    {
        if ((BytesToRead + BytesReadTotal) > BufferSize)
        {
            /* read up to one meg at a time */
            if (BytesToRead < (1024UL * 1024UL))
                BytesToRead *= 2;
            BufferSize += BytesToRead;
            NextBuffer = realloc(File.Contents, BufferSize);
            if (!NextBuffer)
                goto Exit;
            File.Contents = NextBuffer;
        }
        BytesReadOnce = fread(&File.Contents[BytesReadTotal], 1, BytesToRead, StdioFile);
        if (BytesReadOnce == 0 && ferror(StdioFile))
            goto Exit;
        BytesReadTotal += BytesReadOnce;
        if (BytesReadOnce < BytesToRead)
            break;
    }

    NextBuffer = realloc(File.Contents, BytesReadTotal);
    if (!NextBuffer)
        goto Exit;

    File.Contents = NextBuffer;
    File.FileName = FileName;
    File.Size = BytesReadTotal;
    *OutFile = File;
    Status = 0;
Exit:
    if (StdioFile)
        fclose(StdioFile);
    if (Status < 0)
        free(File.Contents);
    return Status;
}

typedef struct STREAM {
    PBYTE  Contents;
    size_t Size;
    size_t NumberOfPages;
} STREAM;

UINT16
Get16(
    void* v
    )
{
    PBYTE b = (PBYTE) v;
    UINT16 a = b[1];
    a <<= 8; a |= b[0];
    return a;
}

UINT32
Get32(
    void* v
    )
{
    PBYTE b = (PBYTE) v;
    UINT32 a = b[3];
    a <<= 8; a |= b[2];
    a <<= 8; a |= b[1];
    a <<= 8; a |= b[0];
    return a;
}

void
CopyStream(
    PPDB_HEADER Header,
    MY_FILE* File,
    STREAM* Stream,
    size_t StreamSize,
    UINT16* Pages
    )
{
    PBYTE FileContents = File->Contents;
    size_t PageSize = Header->PageSize;
    size_t i = 0;

    size_t NumberOfPages = ((StreamSize + PageSize - 1) / PageSize);
    PBYTE Contents = (PBYTE) malloc(StreamSize);

    if (Contents == NULL)
        goto Exit;

    Stream->Size = StreamSize;
    Stream->NumberOfPages = NumberOfPages;
    Stream->Contents = Contents;

    for (i = 0; i != NumberOfPages ; ++i)
    {
        size_t BlockSize;
        size_t PageNumber;

        if (i == (NumberOfPages - 1))
            BlockSize = (StreamSize % PageSize);
        else
            BlockSize = PageSize;

        PageNumber = Get16(&Pages[i]);
        memcpy(Contents + i * PageSize, FileContents + PageNumber * PageSize, BlockSize);
    }
Exit:
    return;
}

void
DumpStream(
    STREAM* Stream,
    size_t Index
    )
{
    size_t Size = Stream->Size;
    PBYTE Contents = Stream->Contents;
    size_t i;

    printf("stream 0x%lx size 0x%lx:\n", (unsigned long)Index, (unsigned long)Stream->Size);
    for (i = 0 ; i != Size ; ++i)
    {
        if ((i != 0) && ((i % 16) == 0))
            printf("\n");
        if ((i % 16) == 0)
            printf("%06lx:", (unsigned long)i);
        if ((i % 8) == 0)
            printf(" ");
        printf("%02x ", Contents[i]);
        if (((i + 1) % 16) == 0)
        {
            size_t j;
            printf(" ");
            for (j = (i - 15) ; j != i ; ++j)
            {
                char c = Contents[j];
                printf("%c", isprint(c) ? c : '.');
            }
        }
    }
    printf("\n");
}

int
__cdecl
main(
    int argc,
    char** argv
    )
{
    int ExitCode = 1;
    long Status = -1;
    MY_FILE File = { 0 };
    PPDB_HEADER Header = 0;
    STREAM Stream = { 0 };
    STREAM* Streams = 0;
    size_t PageSize = 0;
    size_t i = 0;
    size_t j = 0;
    size_t StreamCount = 0;
    UINT16* Pages = 0;
    UINT32* Sizes = 0;

    if (!argv[1])
        goto Exit;

    Status = ReadEntireFileInMemory(argv[1], &File);
    if (Status < 0)
        goto Exit;

    Header = (PPDB_HEADER) File.Contents;
    PageSize = Header->PageSize;
    printf(
        "Signature: %.*s\n"
        "PageSize: 0x%lx\n"
        "StartPage: 0x%lx\n"
        "FilePages: 0x%lx\n"
        "RootStream.StreamSize: 0x%lx\n"
        "RootStream.StreamPages[0]: 0x%lx\n",
        (sizeof(PDB_SIGNATURE1) - 1),
        Header->Signature,
        (unsigned long)Header->PageSize,
        (unsigned long)Header->StartPage,
        (unsigned long)Header->FilePages,
        (unsigned long)Header->RootStreamSize,
        (unsigned long)Header->RootStreamPages[0]
        );

    CopyStream(Header, &File, &Stream, Get32(&Header->RootStreamSize), Header->RootStreamPages);
    DumpStream(&Stream, 0);

    /*
    root stream is
        uint16 StreamCount
        uint16 Reserved
        array {
            uint32 Size
            uint32 Reserved
        }[StreamCount]
        uint16 Pages[]
    */
    StreamCount = Get16(Stream.Contents);
    printf("StreamCount: 0x%lx\n", (unsigned long) StreamCount);
    Sizes = (UINT32*) (Stream.Contents + 4);
    Pages = (UINT16*) (Sizes + 2 * StreamCount);

    Streams = (STREAM*) calloc(StreamCount, sizeof(STREAM));
    for (i = 0; i != StreamCount ; ++i)
    {
        size_t StreamSize = Get32(&Sizes[i * 2]);
        CopyStream(Header, &File, &Streams[i], StreamSize, Pages);
        Pages += Streams[i].NumberOfPages;
        DumpStream(&Streams[i], i);
    }

    printf("\n");

    ExitCode = 0;
Exit:
    free(File.Contents);
    printf("ExitCode:%d\n", ExitCode);
    return ExitCode;
}
